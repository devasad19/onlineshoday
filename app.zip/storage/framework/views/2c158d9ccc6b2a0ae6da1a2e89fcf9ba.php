<?php $__env->startSection('title', 'আমার পণ্য ব্যবস্থাপনা'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-gray-50">
    <!-- 🟢 Sidebar -->
    <!-- <?php echo $__env->make('backend.patrials.rider_aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
 
    <!-- 🟡 Main Content Area -->
    <div class="flex-1 flex flex-col p-4">
        <!-- Top Bar -->
        <?php echo $__env->make('backend.patrials.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="bg-white shadow rounded-lg p-6">

        
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
 
<h1 class="text-2xl font-bold text-gray-700">
    🛒 নিত্যপ্রয়োজনীয় পণ্য 
</h1>

<a
    href="<?php echo e(route('rider.custom.products')); ?>"
    class="inline-flex items-center justify-center gap-2 bg-orange-600 hover:bg-orange-700 text-white font-semibold px-5 py-2.5 rounded-lg shadow-sm transition"
>
    🧩 ই-কমার্স পণ্য তালিকা
</a>
 

</div>



        

        <div class="bg-white border border-gray-200 shadow-sm rounded-xl p-5 mb-10">

            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">

                <div>
                    <h2 class="text-xl font-semibold text-gray-800">
                        🛍️ নিত্যপ্রয়োজনীয় পণ্য তালিকা
                    </h2>

                    <p class="text-sm text-gray-500 mt-1">
                        পণ্যের বিস্তারিত তথ্য দেখুন
                    </p>
                </div>

                <div class="text-sm text-gray-500">
                    মোট <?php echo e($products->total()); ?> টি পণ্য
                </div>

            </div>


            <div class="overflow-x-auto">

                <table class="min-w-full border border-gray-200 rounded-lg overflow-hidden">

                    <thead class="bg-gray-100 text-gray-700">

                        <tr>
                            <th class="p-3 text-left whitespace-nowrap">#</th>
                            <th class="p-3 text-left whitespace-nowrap">পণ্য</th>
                            <th class="p-3 text-left whitespace-nowrap">ক্যাটাগরি</th>
                            <th class="p-3 text-center whitespace-nowrap">ইউনিট</th>
                            <th class="p-3 text-right whitespace-nowrap">মূল দাম</th>
                            <th class="p-3 text-center whitespace-nowrap">ডিসকাউন্ট</th>
                            <th class="p-3 text-center whitespace-nowrap">স্ট্যাটাস</th>
                            <th class="p-3 text-center whitespace-nowrap">অ্যাকশন</th>
                        </tr>

                    </thead>


                    <tbody class="bg-white">

                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <?php
                                $discount = (float) ($product->discount ?? 0);
                                $originalPrice = (float) ($product->price ?? 0);

                                $discountPrice = $discount > 0
                                    ? $originalPrice - (($originalPrice * $discount) / 100)
                                    : $originalPrice;
                            ?>

                            <tr class="border-t hover:bg-gray-50 transition">

                                
                                <td class="p-3 align-top">
                                    <?php echo e($products->firstItem() + $key); ?>

                                </td>


                                
                                <td class="p-3 align-top">

                                    <div class="flex items-center gap-3 min-w-[230px]">

                                        <?php if($product->image): ?>

                                            <img
                                                src="<?php echo e(url('uploads/products/' . $product->image)); ?>"
                                                alt="<?php echo e($product->name); ?>"
                                                class="w-14 h-14 rounded-lg object-cover border border-gray-200"
                                            >

                                        <?php else: ?>

                                            <div class="w-14 h-14 rounded-lg bg-gray-100 border border-gray-200 flex items-center justify-center text-gray-400 text-xl">
                                                📦
                                            </div>

                                        <?php endif; ?>


                                        <div>

                                            <div class="font-semibold text-gray-800">
                                                <?php echo e($product->name); ?>

                                            </div>

                                            <?php if(!empty($product->description)): ?>

                                                <div class="text-xs text-gray-500 mt-1 max-w-xs line-clamp-2">
                                                    <?php echo e($product->description); ?>

                                                </div>

                                            <?php endif; ?>

                                        </div>

                                    </div>

                                </td>


                                
                                <td class="p-3 align-top">

                                    <span class="inline-flex px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 text-sm">

                                        <?php echo e($product->category->name ?? 'ক্যাটাগরি নেই'); ?>


                                    </span>

                                </td>


                                
                                <td class="p-3 text-center align-top">

                                    <span class="inline-flex px-2.5 py-1 rounded-full bg-gray-100 text-gray-700 text-sm">

                                        <?php echo e($product->unit ?: '—'); ?>


                                    </span>

                                </td>


                                
                                <td class="p-3 text-right align-top whitespace-nowrap">

                                    <?php if($discount > 0): ?>

                                        <div class="text-sm text-gray-400 line-through">
                                            <?php echo e(number_format($originalPrice, 2)); ?> ৳
                                        </div>

                                        <div class="font-bold text-gray-800">
                                            <?php echo e(number_format($discountPrice, 2)); ?> ৳
                                        </div>

                                    <?php else: ?>

                                        <div class="font-bold text-gray-800">
                                            <?php echo e(number_format($originalPrice, 2)); ?> ৳
                                        </div>

                                    <?php endif; ?>

                                </td>


                                
                                <td class="p-3 text-center align-top">

                                    <?php if($discount > 0): ?>

                                        <span class="inline-flex px-2.5 py-1 rounded-full bg-orange-100 text-orange-700 text-sm font-semibold">
                                            <?php echo e(number_format($discount, 0)); ?>%
                                        </span>

                                    <?php else: ?>

                                        <span class="text-gray-400 text-sm">
                                            নেই
                                        </span>

                                    <?php endif; ?>

                                </td>


                                
                                <td class="p-3 text-center align-top whitespace-nowrap">

                                    <?php if($product->available): ?>

                                        <span class="inline-flex px-2.5 py-1 rounded-full bg-green-100 text-green-700 text-sm font-semibold">
                                            ✓ Available
                                        </span>

                                    <?php else: ?>

                                        <!-- <span class="inline-flex px-2.5 py-1 rounded-full bg-red-100 text-red-700 text-sm font-semibold">
                                            ✕ Unavailable
                                        </span> -->

                                    <?php endif; ?>


                                    <div class="mt-1">

                                        <?php if($product->status): ?>

                                            <span class="text-xs text-green-600">
                                                Active
                                            </span>

                                        <?php else: ?>

                                            <span class="text-xs text-red-600">
                                                Inactive
                                            </span>

                                        <?php endif; ?>

                                    </div>

                                </td>


                                
                                <td class="p-3 text-center align-top">

                                    <a
                                        href="<?php echo e(route('home.product.details', $product->id)); ?>"
                                        class="inline-block bg-purple-600 hover:bg-purple-700 text-white text-sm font-medium py-2 px-4 rounded-lg transition"
                                    >
                                        বিস্তারিত
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>

                                <td colspan="8" class="p-8 text-center text-gray-500">
                                    কোনো পণ্য পাওয়া যায়নি।
                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>


            
            <?php if($products->hasPages()): ?>

                <div class="mt-6">
                    <?php echo e($products->appends(request()->except('products_page'))->links()); ?>

                </div>

            <?php endif; ?>

        </div>


 

    </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('apps.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineshoday\resources\views/backend/riders/my_products.blade.php ENDPATH**/ ?>