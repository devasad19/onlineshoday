<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-gray-50">

    

    <!-- 🟡 Main Content Area -->
    <div class="flex-1 min-w-0 flex flex-col">
        <?php echo $__env->make('backend.patrials.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Page Title -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-green-700">📋 Customer List</h2>
        </div>

        <!-- Filter -->
        <div class="flex justify-end mb-4">
            <select class="border px-3 py-2 rounded-lg focus:ring-2 focus:ring-green-400 outline-none">
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="7_days">Last 7 Days</option>
                <option value="15_days">Last 15 Days</option>
                <option value="1_month">1 Month</option>
            </select>
        </div>

        <!-- Customer Table -->
<div class="w-full overflow-x-auto">
    <table class="min-w-[900px] border-collapse whitespace-nowrap">
                <thead>
                    <tr class="bg-green-50 text-gray-700">
                        <th class="py-2 px-4 border">#</th>
                        <th class="py-2 px-4 border">Name</th>
                        <th class="py-2 px-4 border">Email</th>
                        <th class="py-2 px-4 border">Phone</th>
                        <th class="py-2 px-4 border">Total Orders</th>
                        <th class="py-2 px-4 border">Pending Orders</th>
                        <th class="py-2 px-4 border">Status</th>
                        <th class="py-2 px-4 border">Options</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-green-50">
                        <td class="py-2 px-4 border"><?php echo e($index + 1); ?></td>
                        <td class="py-2 px-4 border"><?php echo e($customer->name); ?></td>
                        <td class="py-2 px-4 border"><?php echo e($customer->email); ?></td>
                        <td class="py-2 px-4 border"><?php echo e($customer->phone); ?></td>
                        <td class="py-2 px-4 border"><?php echo e($customer->total_orders); ?></td>
                        <td class="py-2 px-4 border"><?php echo e($customer->pending_orders); ?></td>
                        <td class="py-2 px-4 border">
                            <?php if($customer->status == 'active'): ?>
                                <span class="text-green-600 font-semibold">Active</span>
                            <?php else: ?>
                                <span class="text-red-600 font-semibold">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td class="py-2 px-4 border flex gap-2 md:p-6">
                            <button class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600 transition" 
                                    onclick="alert('View Customer Details')">View</button>
                            <button class="bg-yellow-400 text-white px-2 py-1 rounded hover:bg-yellow-500 transition" 
                                    onclick="alert('Edit Customer')">Edit</button>
                            <button class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 transition" 
                                    onclick="alert('Delete Customer')">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('apps.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebazar\resources\views/backend/admin-dashboard/customer_list.blade.php ENDPATH**/ ?>