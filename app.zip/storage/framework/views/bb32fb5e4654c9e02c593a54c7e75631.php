<?php $__env->startSection('content'); ?>
<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-7xl mx-auto px-4">
        <h2 class="text-3xl font-bold text-green-700 mb-8 text-center">🛍️ সব পণ্য দেখুন</h2>

        <!-- 🔍 Filter Section -->
        <form method="GET" action="<?php echo e(route('products.filter')); ?>" class="bg-white p-6 rounded-2xl shadow mb-8">
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
                <input type="text" name="keyword" value="<?php echo e($keyword); ?>" placeholder="🔎 পণ্য সার্চ করুন"
                    class="border px-3 py-2 rounded-lg focus:ring-2 focus:ring-green-400 outline-none">

                <select name="category_id" class="border px-3 py-2 rounded-lg focus:ring-2 focus:ring-green-400 outline-none">
                    <option value="">ক্যাটাগরি</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e($category_id == $cat->id ? 'selected' : ''); ?>>
                            <?php echo e($cat->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <select name="bazar_id" class="border px-3 py-2 rounded-lg focus:ring-2 focus:ring-green-400 outline-none">
                    <option value="">বাজার</option>
                    <?php $__currentLoopData = $bazars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bz->id); ?>" <?php echo e($bazar_id == $bz->id ? 'selected' : ''); ?>>
                            <?php echo e($bz->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
  
                
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-lg font-semibold transition">
                    🔍 ফিল্টার করুন
                </button>
            </div>
            <div class="mt-4 flex justify-end">
            </div>
        </form>

        <!-- 🧺 Product List -->
        <?php if($products->count()): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="bg-white rounded-xl shadow hover:shadow-lg transition p-4 relative group">
        <img src="<?php echo e(url('uploads/products/'.$product->image)); ?>" 
             alt="<?php echo e($product->name); ?>" 
             class="rounded-lg w-full h-44 object-cover group-hover:scale-105 transition duration-300">
        <button class="absolute top-3 right-3 bg-white p-2 rounded-full shadow hover:text-red-500">
          ❤️
        </button>
        <div class="mt-4">
           <a href="<?php echo e(route('home.product.details', $product->id)); ?>"  class="font-bold text-lg"><?php echo e($product->name); ?></a>
          <p class="text-green-600 font-semibold">৳<?php echo e(bnNum($product->price)); ?> / <?php echo e($product->unit); ?></p>
          <!-- <p class="text-sm text-gray-500">
            বিতরণকারী: 
            <?php echo e(optional($product->rider)->name ?? 'N/A'); ?>

          </p> -->
          <p class="text-sm text-gray-500 mb-3">
            বাজার:  <?php echo e(optional($product->bazar)->name ?? 'N/A'); ?>

          </p>
          <div class="flex justify-between items-center">
              <button class="addToCartBtn inline-block bg-indigo-600 hover:bg-indigo-700 text-sm text-white py-2 px-3 rounded-lg text-sm"
                    data-id="<?php echo e($product->id); ?>"
                    data-name="<?php echo e($product->name); ?>"
                    data-price="<?php echo e($product->price); ?>"
                    data-image="<?php echo e(url('uploads/products/'.$product->image)); ?>">
              🛒 ব্যাগে যোগ করুন
            </button>
            <a href="<?php echo e(route('home.product.details', $product->id)); ?>"  class="inline-block text-sm bg-green-600 text-white py-2 px-3 rounded-lg hover:bg-green-700 transition text-center">
              বিস্তারিত </a>
        </div>
        </div>
      </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-8">
                 
            </div>
        <?php else: ?>
            <p class="text-center text-gray-600 text-lg mt-10">❌ কোনো পণ্য পাওয়া যায়নি।</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('apps.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebazar\resources\views/products_all.blade.php ENDPATH**/ ?>