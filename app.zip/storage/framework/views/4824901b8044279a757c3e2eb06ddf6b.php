<?php $__env->startSection('content'); ?>
 
    <!-- 🟢 সাইডবার -->
    <!-- <?php echo $__env->make('backend.patrials.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->

    <!-- 🟡 মূল কন্টেন্ট -->
    <div class="flex-1 flex flex-col p-2 md:p-6">
        <!-- টপ বার -->
        <?php echo $__env->make('backend.patrials.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- 🎁 অফার নোটিশ -->
        <div id="offerNotice"
            class="bg-gradient-to-r from-green-500 to-green-700 text-white p-5 rounded-2xl shadow-md mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-3 transition-all duration-300">
            <p class="font-semibold text-lg">
                🎉 <span class="font-bold">বিশেষ অফার!</span>
                এই সপ্তাহে তাজা সবজিতে <span class="underline decoration-white">১০% ছাড়</span>।
            </p>
            <div class="flex items-center gap-3">
                <a href="<?php echo e(route('user.my_cart')); ?>" 
                   class="bg-white text-green-700 font-semibold px-4 py-2 rounded-lg hover:bg-green-100 transition">
                    🛒 এখনই অর্ডার করুন
                </a>
                <button onclick="closeOfferNotice()" class="text-white hover:text-gray-200 text-2xl font-bold leading-none">&times;</button>
            </div>
        </div>

        <!-- 🧮 সারাংশ কার্ড -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white rounded-2xl shadow-md p-6 flex items-center justify-between border-l-4 border-green-500">
                <div>
                    <h3 class="text-lg font-semibold text-gray-700">মোট অর্ডার</h3>
                    <p class="text-3xl font-bold text-green-600"><?php echo e(bnNum($totalOrders)); ?></p>
                </div>
                <span class="text-4xl">📦</span>
            </div>

            <div class="bg-white rounded-2xl shadow-md p-6 flex items-center justify-between border-l-4 border-yellow-500">
                <div>
                    <h3 class="text-lg font-semibold text-gray-700">অপেক্ষমান</h3>
                    <p class="text-3xl font-bold text-yellow-500"><?php echo e(bnNum($pendingOrders)); ?></p>
                </div>
                <span class="text-4xl">⏳</span>
            </div>

            <div class="bg-white rounded-2xl shadow-md p-6 flex items-center justify-between border-l-4 border-blue-500">
                <div>
                    <h3 class="text-lg font-semibold text-gray-700">সম্পন্ন</h3>
                    <p class="text-3xl font-bold text-blue-600"><?php echo e(bnNum($completedOrders)); ?></p>
                </div>
                <span class="text-4xl">✅</span>
            </div>
        </div>

        <!-- 🧾 সাম্প্রতিক অর্ডার কার্ড -->
        <h3 class="text-xl font-semibold text-gray-800 mt-8 mb-4">📋 সাম্প্রতিক অর্ডারসমূহ</h3>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white p-3 md:p-6 rounded-2xl shadow hover:shadow-lg transition relative border-t-4 
                        <?php if($order->status === 'pending'): ?> border-yellow-500 
                        <?php elseif($order->status === 'delivered'): ?> border-green-600 
                        <?php elseif($order->status === 'cancelled'): ?> border-red-500 
                        <?php else: ?> border-gray-400 <?php endif; ?>">

                <h4 class="text-lg font-bold text-gray-800 mb-2">🆔 অর্ডার কোড: #<?php echo e($order->order_code); ?></h4>
                
                <div class="text-sm text-gray-700 mb-3">
                    <p><span class="font-semibold">অবস্থা:</span>
                        <?php if($order->status === 'pending'): ?>
                            <span class="text-yellow-600 font-semibold">⏳ অপেক্ষমান</span>
                        <?php elseif($order->status === 'delivered'): ?>
                            <span class="text-green-600 font-semibold">✅ সম্পন্ন</span>
                        <?php elseif($order->status === 'cancelled'): ?>
                            <span class="text-red-500 font-semibold">❌ বাতিল</span>
                        <?php else: ?>
                            <span class="text-gray-500"><?php echo e(ucfirst($order->status)); ?></span>
                        <?php endif; ?>
                    </p>
                    <p><span class="font-semibold">নাম:</span> <?php echo e($order->user->name); ?></p>
                    <p><span class="font-semibold">তারিখ:</span> <?php echo e($order->created_at->format('d M, Y h:i A')); ?></p>
                    <p><span class="font-semibold">মোট মূল্য:</span> ৳<?php echo e(bnNum($order->total_amount, 2)); ?></p>
                </div>

                <div class="mb-3">
                    <h5 class="font-semibold text-gray-700 mb-1">🛒 পণ্যসমূহ:</h5>
                    <ul class="text-sm text-gray-600 space-y-1">
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>• <?php echo e($item->product->name); ?> – <?php echo e(bnNum($item->quantity)); ?> <?php echo e($item->product->unit ?? 'টি'); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <!-- Delivery status -->
                <?php
                    $deliveryStatus = '';
                    if ($order->delivery_at) {
                        $expected = \Carbon\Carbon::parse($order->delivery_at);
                        $delivered = $order->delivered_at ? \Carbon\Carbon::parse($order->delivered_at) : null;

                        if ($delivered) {
                            $deliveryStatus = $delivered->gt($expected)
                                ? '❌ বিলম্বিত'
                                : '✅ সময়ে পৌঁছেছে';
                        } else {
                            $deliveryStatus = '🚚 পথে রয়েছে';
                        }
                    }
                ?>

                <div class="mt-3 text-sm font-semibold
                    <?php if(str_contains($deliveryStatus, 'বিলম্ব')): ?> text-red-600 
                    <?php elseif(str_contains($deliveryStatus, 'সময়')): ?> text-green-600 
                    <?php else: ?> text-blue-600 <?php endif; ?>">
                    📦 ডেলিভারি স্ট্যাটাস: <?php echo e($deliveryStatus); ?>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center col-span-3 py-10 text-gray-500">
                😔 এখনো কোনো অর্ডার দেওয়া হয়নি
            </div>
            <?php endif; ?>
        </div>
    </div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
function closeOfferNotice() {
    const notice = document.getElementById('offerNotice');
    notice.classList.add('opacity-0', 'translate-y-3');
    setTimeout(() => notice.remove(), 300);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('apps.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebazar\resources\views/backend/user-dashboard/index.blade.php ENDPATH**/ ?>