<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-gray-50">

    <!-- Sidebar -->
 

    <!-- Main Area -->
    <div class="flex-1 flex flex-col">

        <?php echo $__env->make('backend.patrials.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content -->
        <section class="bg-white p-6 rounded-2xl shadow mx-6 my-6">
            <h2 class="text-2xl font-bold text-green-700 mb-6">📦 লাইভ অর্ডার বোর্ড</h2>

            <!-- Filter -->
             <!-- Filter -->
<div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">

<form method="GET" action="<?php echo e(route('rider.orders')); ?>">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">

        <div class="flex items-center gap-2">

            <label class="font-semibold">তারিখ:</label>

            <select name="date_filter"
                    onchange="this.form.submit()"
                    class="border rounded-lg px-3 py-2">

                <option value="today"
                    <?php echo e(request('date_filter')=='today'?'selected':''); ?>>
                    Today
                </option>

                <option value="yesterday"
                    <?php echo e(request('date_filter')=='yesterday'?'selected':''); ?>>
                    Yesterday
                </option>

                <option value="range"
                    <?php echo e(request('date_filter')=='range'?'selected':''); ?>>
                    Date Range
                </option>

                <option value="all"
                    <?php echo e(request('date_filter','all')=='all'?'selected':''); ?>>
                    All Orders
                </option>

            </select>

            <input type="date"
                   name="from_date"
                   value="<?php echo e(request('from_date')); ?>"
                   onchange="this.form.submit()"
                   class="border rounded-lg px-3 py-2 <?php echo e(request('date_filter')=='range' ? '' : 'hidden'); ?>">

            <span class="<?php echo e(request('date_filter')=='range' ? '' : 'hidden'); ?>">-</span>

            <input type="date"
                   name="to_date"
                   value="<?php echo e(request('to_date')); ?>"
                   onchange="this.form.submit()"
                   class="border rounded-lg px-3 py-2 <?php echo e(request('date_filter')=='range' ? '' : 'hidden'); ?>">

        </div>

        <div>

            <input
                type="text"
                name="search"
                value="<?php echo e(request('search')); ?>"
                placeholder="Customer Name, Phone"
                class="border rounded-lg px-3 py-2 w-64">

        </div>

        <div>

            <select
                name="status"
                onchange="this.form.submit()"
                class="border rounded-lg px-3 py-2">

                <option value="">All</option>

                <option value="accepted"
                    <?php echo e(request('status')=='accepted'?'selected':''); ?>>
                    Accepted
                </option>

                <option value="rider_modified_accepted"
                    <?php echo e(request('status')=='rider_modified_accepted'?'selected':''); ?>>
                    Modified
                </option>

                <option value="delivered"
                    <?php echo e(request('status')=='delivered'?'selected':''); ?>>
                    Delivered
                </option>

            </select>

        </div>

        <button
            class="bg-green-600 text-white px-5 py-2 rounded-lg">

            Search

        </button>

    </div>
</form>
 

</div>
 
            <!-- Orders Table -->
            <div class="overflow-x-auto">
                

<?php if($orders->count() > 0): ?>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            // 🧮 Calculate total by unit
           $totals = [
    'কেজি' => [],
    'পিস' => [],
    'ডজন' => [],
    'লিটার' => [],
    'প্যাকেট' => [],
    'টাকা' => []
];

// 👉 1. Normal products
foreach ($order->items as $i) {
    $name = $i->product->name ?? 'অজানা পণ্য';
    $unit = trim($i->product->unit ?? '');
    $qty = floatval($i->quantity ?? 0);

    if ($unit && array_key_exists($unit, $totals)) {
        // ✅ প্রতিটি পণ্যের সাথেই unit যোগ করছি
        $totals[$unit][] = "{$name} ({$qty} {$unit})";
    }
}

// 👉 2. Custom products (from JSON field)
if (!empty($order->custom_products)) {
    foreach ($order->custom_products as $cp) {
        $name = $cp['name'] ?? 'অজানা পণ্য';
        $qty = floatval($cp['quantity'] ?? 0);
        $price = floatval($cp['price'] ?? 0);
        $unit = trim($cp['unit'] ?? '');

        if ($unit === 'টাকা') {
            $totals['টাকা'][] = "{$name} ({$price} টাকা)";
        } elseif ($unit && array_key_exists($unit, $totals)) {
            $totals[$unit][] = "{$name} ({$qty} {$unit})";
        } else {
            // unit না থাকলে default টাকা ধরা
            $totals['টাকা'][] = "{$name} ({$price} টাকা)";
        }
    }
}

// 👉 3. Final formatted text
$totalTextParts = [];

foreach (['কেজি','পিস','ডজন','লিটার','প্যাকেট','টাকা'] as $unit) {
    if (count($totals[$unit]) > 0) {
        // ✅ এখন আলাদা আলাদা পণ্য, শেষে আর আলাদা unit লাগবে না
        $totalTextParts[] = implode(', ', $totals[$unit]);
    }
}

$totalText = implode(', ', $totalTextParts) ?: '-';
 
        ?>

        <div class="w-full mb-4">
            <div class="relative bg-white p-5 mt-2 rounded-2xl shadow-md hover:shadow-lg transition order-item border border-gray-100 w-full">
    
    <span class="absolute -top-3 left-5 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow">
        অর্ডার আইডি: #<?php echo e($order->id); ?>

    </span>


                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">

                    <!-- 🧍‍♂️ Customer Info -->
                    <div>
                        <h4 class="text-lg font-semibold text-green-700 mb-1">
                            <?php echo e($order->user->name ?? 'অজানা ক্রেতা'); ?>

                        </h4>
                        <p class="text-sm text-gray-600">পিতার নামঃ <?php echo e($order->user->father_name ?? '-'); ?></p>
                        <p class="text-sm text-gray-600">📞 <?php echo e($order->user->phone ?? '-'); ?></p>
                    </div>

                    <!-- 📦 Order Info -->
                    <div class="text-gray-700">
                        <p><strong>পণ্যঃ</strong> <?php echo e(count($order->items)); ?> টি</p>
                        <p><strong>মোটঃ</strong> <span class="text-green-700 font-semibold">৳ <?php echo e($order->total_amount); ?></span></p>
                        <p><strong>ঠিকানাঃ</strong> <?php echo e($order->delivery_address ?? '-'); ?></p>
                    </div>

                    <!-- ⏰ Time & Action -->
                    <div class="flex flex-col justify-between text-left md:text-right">
                        <p class="text-sm text-gray-500 mb-3">
                            <strong>অর্ডার সময়ঃ</strong> <?php echo e($order->created_at); ?> <br>
                            <?php if($order->status == 'delivered'): ?>
                            <strong class="text-red-600">ডেলিভারি হয়েছেঃ</strong> <?php echo e($order->delivered_at); ?>

                            <?php endif; ?>
                        </p>
                        
                        <?php if($order->status == 'accepted'): ?>
                            <button  class="deliverBtn bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded-lg transition w-full md:w-auto"
                                data-id="<?php echo e($order->id); ?>">
                                ✅ ডেলিভারি সম্পন্ন করুন
                            </button>
                            <p class="text-xs p-3 ">এস্টিমেট ডেলিভারি সময়ঃ <?php echo e($order->delivery_time); ?> মিনিট</p>
                        <?php elseif($order->status == 'rider_modified_accepted'): ?>
                            <button  class="bg-yellow-600 hover:bg-yellow-700 text-white font-semibold px-6 py-2 rounded-lg transition w-full md:w-auto">
                                ✅ মুল্য বর্ধিত পাঠানো হয়েছে
                            </button>
                        <?php elseif($order->status == 'delivered'): ?>
                            <button  class="bg-gray-600 hover:bg-gray-700 text-white font-semibold px-6 py-2 rounded-lg transition w-full md:w-auto">
                                ✅ ডেলিভারি সম্পন্ন হয়েছে
                            </button>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 🧮 Total Qty -->
                <p class="text-sm text-red-500 mt-3"><strong>মোট পরিমাণঃ</strong> <?php echo e($totalText); ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p class="text-gray-600">📭 কোনো অর্ডার পাওয়া যায়নি।</p>
<?php endif; ?>

 
 

            </div>
        </section>




    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
$(document).on('click', '.deliverBtn', function () {
    const btn = $(this);
    const orderId = btn.data('id');

    btn.prop('disabled', true).text('⏳ প্রসেস হচ্ছে...');

    $.ajax({
        url: "<?php echo e(route('rider.orders.deliver', ':id')); ?>".replace(':id', orderId),
        method: "POST",
        data: {
            _token: "<?php echo e(csrf_token()); ?>"
        },
        success: function (res) {
            if (res.success) {
                // Success Notification
                Swal.fire({
                    icon: 'success',
                    title: 'সফল!',
                    text: res.message,
                    confirmButtonColor: '#16a34a',
                });

                // Button Update
                btn
                    .removeClass('bg-green-600 hover:bg-green-700')
                    .addClass('bg-gray-400 cursor-not-allowed')
                    .text('✅ ডেলিভারি সম্পন্ন হয়েছে')
                    .prop('disabled', true);
            } else {
                Swal.fire({
                    icon: 'warning',
                    title: 'সতর্কতা',
                    text: res.message || 'কিছু ভুল হয়েছে!',
                    confirmButtonColor: '#f59e0b',
                });
                btn.prop('disabled', false).text('✅ ডেলিভারি সম্পন্ন');
            }
        },
        error: function () {
            Swal.fire({
                icon: 'error',
                title: 'ত্রুটি!',
                text: 'সার্ভারে সমস্যা হয়েছে, আবার চেষ্টা করুন।',
                confirmButtonColor: '#dc2626',
            });
            btn.prop('disabled', false).text('✅ ডেলিভারি সম্পন্ন');
        }
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('apps.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebazar\resources\views/backend/riders/rider_orders.blade.php ENDPATH**/ ?>