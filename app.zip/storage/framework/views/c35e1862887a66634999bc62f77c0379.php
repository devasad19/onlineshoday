            <div class="w-full overflow-x-auto">
                <table class="min-w-[900px] border-collapse whitespace-nowrap">

<thead class="bg-green-600 text-white">

<tr>

<th class="px-4 py-3 text-left">#</th>
<th class="px-4 py-3 text-left">পণ্যের নাম</th>
<th class="px-4 py-3 text-left">ছবি</th>
<th class="px-4 py-3 text-left">বাজার</th>
<th class="px-4 py-3 text-left">বিভাগ</th>
<th class="px-4 py-3 text-left">মূল্য</th>
<th class="px-4 py-3 text-left">স্ট্যাটাস</th>
<th class="px-4 py-3 text-center">অপশন</th>
<th class="px-4 py-3 text-center">---</th>
<th class="px-4 py-3 text-left">প্রাইস আপডেট</th>

</tr>

</thead>

<tbody class="divide-y divide-gray-200">

<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<tr>
<td class="px-4 py-3"><?php echo e($products->firstItem()+$key); ?></td>

<td class="px-4 py-3"><?php echo e($product->name); ?></td>

<td class="px-4 py-3">
    <img src="<?php echo e(asset('uploads/products/'.$product->image)); ?>"
         class="w-20 h-20 rounded border object-cover">
</td>

<td class="px-4 py-3"><?php echo e($product->bazar->name ?? 'N/A'); ?></td>

<td class="px-4 py-3"><?php echo e($product->category->name ?? 'N/A'); ?></td>

<td class="px-4 py-3" id="price-text-<?php echo e($product->id); ?>">
    ৳<?php echo e(number_format($product->price,2)); ?>

</td>

<td>

<?php if($product->status=='active'): ?>

<span class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-700">
সক্রিয়
</span>

<?php else: ?>

<span class="px-2 py-1 text-xs rounded-full bg-red-100 text-red-700">
নিষ্ক্রিয়
</span>

<?php endif; ?>

</td>

<td class="text-center">

<button onclick="viewProduct(<?php echo e($product->id); ?>)">👁️</button>

<a href="<?php echo e(route('admin.products.edit',$product->id)); ?>"
   class="text-yellow-600">
    ✏️
</a>

<button onclick="confirmDelete(<?php echo e($product->id); ?>)">🗑️</button>

</td>
<td>---</td>
 
<td class="min-w-[170px]">

    <div class="flex items-center gap-2">

        <span>৳</span>

        <input
            type="number"
            step="0.01"
            value="<?php echo e($product->price); ?>"
            class="price-input border rounded px-2 py-1 w-24"
            data-id="<?php echo e($product->id); ?>">

        <span
            id="price-status-<?php echo e($product->id); ?>"
            class="text-xs">
        </span>
<span
    id="updated-badge-<?php echo e($product->id); ?>"
    class="text-xs <?php echo e($product->price_updated_at?->isToday() ? 'text-green-600' : 'text-gray-400'); ?>">
    
    <?php echo e($product->price_updated_at?->isToday() ? 'Updated' : 'Not Today'); ?>


</span>
    </div>

</td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<tr>

<td colspan="6" class="text-center py-5">

কোনো পণ্য পাওয়া যায়নি।

</td>

</tr>

<?php endif; ?>

</tbody>

</table>

<div class="mt-5">

<?php echo e($products->links()); ?>


</div>

</div><?php /**PATH C:\xampp\htdocs\ebazar\resources\views/backend/admin-dashboard/products/partials/product_table.blade.php ENDPATH**/ ?>