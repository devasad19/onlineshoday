

<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-gray-50">
    

    <!-- 🟡 Main Content -->
    <div class="flex-1 flex flex-col">
        <?php echo $__env->make('backend.patrials.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Body -->
        <section class="bg-white p-2 md:p-6 m-2 md:m-6 rounded-2xl shadow border border-gray-200">

        <?php echo $__env->make('alerts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <h2 class="text-2xl font-bold text-green-700 mb-6">➕ পণ্য সংশোধন করুন</h2>

            <!-- Product Add Form -->
            <form id="editProductForm"
                action="<?php echo e(route('admin.products.update',$product->id)); ?>"
                method="POST"
                enctype="multipart/form-data"
                class="grid grid-cols-1 md:grid-cols-2 gap-6">

                <?php echo csrf_field(); ?>
               

                <!-- Product Name -->
                <div>
                    <label class="block font-semibold text-gray-700 mb-2">পণ্যের নাম *</label>
                    <input
                        type="text"
                        name="name"
                        value="<?php echo e(old('name',$product->name)); ?>"
                        required
                        class="w-full border border-gray-400 rounded-lg px-3 py-2">
                </div>

                <!-- Bazar -->
                <div>
                    <label class="block font-semibold text-gray-700 mb-2">বাজার নির্বাচন *</label>

                    <select
                        name="bazar_id"
                        required
                        class="w-full border border-gray-400 rounded-lg px-3 py-2">

                        <?php $__currentLoopData = $bazars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bazar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                value="<?php echo e($bazar->id); ?>"
                                <?php echo e(old('bazar_id',$product->bazar_id)==$bazar->id ? 'selected' : ''); ?>>

                                <?php echo e($bazar->name); ?>


                            </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>

                <!-- Category -->

                <div>

                    <label class="block font-semibold text-gray-700 mb-2">

                        ক্যাটাগরি *

                    </label>

                    <select
                        name="category_id"
                        required
                        class="w-full border border-gray-400 rounded-lg px-3 py-2">

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                value="<?php echo e($cat->id); ?>"
                                <?php echo e(old('category_id',$product->category_id)==$cat->id ? 'selected' : ''); ?>>

                                <?php echo e($cat->name); ?>


                            </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>

                <!-- Price -->

                <div>

                    <label class="block font-semibold text-gray-700 mb-2">

                        মূল্য

                    </label>

                    <input
                        type="number"
                        min="0"
                        step="0.01"
                        name="price"
                        value="<?php echo e(old('price',$product->price)); ?>"
                        class="w-full border border-gray-400 rounded-lg px-3 py-2">

                </div>

                <!-- Unit -->

                <div>

                    <label class="block font-semibold text-gray-700 mb-2">

                        ইউনিট

                    </label>

                    <select
                        name="unit"
                        class="w-full border border-gray-400 rounded-lg px-3 py-2">

                        <?php

                            $units=[
                                'কেজি',
                                'পিস',
                                'ডজন',
                                'লিটার',
                                'প্যাকেট'
                            ];

                        ?>

                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                value="<?php echo e($unit); ?>"
                                <?php echo e(old('unit',$product->unit)==$unit ? 'selected' : ''); ?>>

                                <?php echo e($unit); ?>


                            </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>

                <!-- Status -->

                <div>

                    <label class="block font-semibold text-gray-700 mb-2">

                        স্ট্যাটাস

                    </label>

                    <select
                        name="status"
                        class="w-full border border-gray-400 rounded-lg px-3 py-2">

                        <option
                            value="active"
                            <?php echo e(old('status',$product->status)=='active' ? 'selected' : ''); ?>>

                            Active

                        </option>

                        <option
                            value="inactive"
                            <?php echo e(old('status',$product->status)=='inactive' ? 'selected' : ''); ?>>

                            Inactive

                        </option>

                    </select>

                </div>

                <!-- Image -->

                <div>

                    <label class="block font-semibold text-gray-700 mb-2">

                        বর্তমান ছবি

                    </label>

                    <img
                        src="<?php echo e(asset('uploads/products/'.$product->image)); ?>"
                        class="w-24 h-24 rounded border object-cover mb-2">

                    <input
                        type="file"
                        name="image"
                        class="w-full border border-gray-400 rounded-lg px-3 py-2">

                </div>

                <!-- Description -->

                <div class="md:col-span-2">

                    <label class="block font-semibold text-gray-700 mb-2">

                        বর্ণনা

                    </label>

                    <textarea
                        name="description"
                        rows="4"
                        class="w-full border border-gray-400 rounded-lg px-3 py-2"><?php echo e(old('description',$product->description)); ?></textarea>

                </div>

                <div class="md:col-span-2 flex justify-end">

                    <button
                        id="saveBtn"
                        class="bg-green-600 text-white px-6 py-2 rounded-lg">

                        ✏️ Update Product

                    </button>

                </div>

            </form>
            
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const alertBox = document.getElementById('alert-message');
    if (alertBox) {
        // Fade in
        setTimeout(() => {
            alertBox.classList.remove('opacity-0', 'translate-y-[-20px]');
            alertBox.classList.add('opacity-100', 'translate-y-0');
        }, 100);

        // Fade out after 3 seconds
        setTimeout(() => {
            alertBox.classList.remove('opacity-100', 'translate-y-0');
            alertBox.classList.add('opacity-0', 'translate-y-[-20px]');
        }, 3000);

        // Remove from DOM after fade out
        setTimeout(() => alertBox.remove(), 3500);
    }
});





$("#editProductForm").submit(function(e){

    e.preventDefault();

    let formData = new FormData(this);

    $.ajax({

        url: $(this).attr("action"),

        type: "POST",

        data: formData,

        processData: false,

        contentType: false,

        success: function(res){

            Swal.fire({
                icon:'success',
                title:res.message,
                timer:1500,
                showConfirmButton:false
            }).then(()=>{
                window.location.href="<?php echo e(route('admin.manage_products')); ?>";
            });

        }

    });

});







</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('apps.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebazar\resources\views/backend/admin-dashboard/products/update_product.blade.php ENDPATH**/ ?>