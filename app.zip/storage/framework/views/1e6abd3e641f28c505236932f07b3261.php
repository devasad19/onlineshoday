        <?php if(session('success')): ?>
            <div id="alert-message" 
                class="fixed top-5 right-5 z-50 w-auto max-w-sm bg-green-100 text-green-800 border border-green-300 rounded-lg shadow-lg p-4 transition-all transform duration-500 opacity-0 translate-y-[-20px]">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
            
        <?php if(session('error')): ?>
            <div id="alert-message" class="fixed top-5 right-5 z-50 w-auto max-w-sm bg-red-100 text-red-800 border border-red-300 rounded-lg shadow-lg p-4 transition-all transform duration-500 opacity-0 translate-y-[-20px]">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
             
        <?php if($errors->any()): ?>
            <div class="bg-red-100 text-red-700 px-4 py-2 rounded mb-4">
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>



<?php /**PATH C:\xampp\htdocs\ebazar\resources\views/alerts/alert.blade.php ENDPATH**/ ?>