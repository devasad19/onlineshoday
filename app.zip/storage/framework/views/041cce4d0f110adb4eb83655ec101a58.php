<?php $__env->startSection('content'); ?>
<div class="bg-gray-50 min-h-screen py-10">
    <div class="max-w-7xl mx-auto px-4">
        <h2 class="text-3xl font-bold text-green-700 mb-8 text-center">🏪 আমাদের বাজার তালিকা</h2>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <?php $__currentLoopData = $bazars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bazar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white p-6 rounded-2xl shadow hover:shadow-xl transition flex flex-col gap-3">
        <div class="flex-1">
            <h3 class="text-2xl font-semibold text-gray-800 mb-2"><?php echo e($bazar->name); ?></h3>
            <p class="text-gray-600">রাইডার সংখ্যা: <strong><?php echo e(count($bazar->riders)); ?></strong></p>
            <p class="text-gray-600">পণ্যের সংখ্যা: <strong><?php echo e(count($bazar->products)); ?></strong></p>

            <p class="text-gray-600 mt-2">কভার করা এলাকা/গ্রাম:</p>
            <div class="flex flex-wrap mt-2 gap-2">
                <?php $__empty_1 = true; $__currentLoopData = $bazar->areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm"><?php echo e($area->name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-4 text-yellow-500 text-xs text-gray-500 py-1">
                    🚫 কোনো এলাকা/গ্রাম পাওয়া যায়নি।
                </div>
                <?php endif; ?>
            </div>
        </div>
 
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


        <!-- Pagination -->
      

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('apps.front_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebazar\resources\views/bazars.blade.php ENDPATH**/ ?>