<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\Bazar;
use App\Models\Rider;
use Carbon\Carbon;
use App\Models\Order;
use App\Models\Package;
use App\Models\User;
use App\Models\DeliveryChargeRule;
use App\Models\CustomProduct;
use Illuminate\Support\Facades\DB;

class AdminDashboardController extends Controller
{

    

    public function adminDashboard()
    {
        $today = Carbon::today();

        /*
        |--------------------------------------------------------------------------
        | Orders
        |--------------------------------------------------------------------------
        */

        $deliveredOrders = Order::where(function ($query) {
            $query->where('status', 'delivered')
                ->orWhere('delivered_status', 'delivered');
        });

        $totalOrders = Order::count();

        $todayOrders = Order::whereDate(
            'created_at',
            $today
        )->count();

        $pendingOrders = Order::whereNotIn(
            'status',
            ['delivered', 'canceled', 'cancelled']
        )->count();

        $cancelOrders = Order::whereIn(
            'status',
            ['canceled', 'cancelled']
        )->count();


        /*
        |--------------------------------------------------------------------------
        | Sales
        |--------------------------------------------------------------------------
        */

        $totalSell = (clone $deliveredOrders)
            ->sum('total_amount');


        $todayPendingAmount = Order::whereDate(
            'created_at',
            $today
        )
        ->whereNotIn(
            'status',
            ['delivered', 'canceled', 'cancelled']
        )
        ->sum('total_amount');


        /*
        |--------------------------------------------------------------------------
        | Delivery Charge
        |--------------------------------------------------------------------------
        */

        $totalDeliveryCharge = (clone $deliveredOrders)
            ->sum('delivery_charge');


        $todayDeliveryCharge = (clone $deliveredOrders)
            ->whereDate(
                'delivered_at',
                $today
            )
            ->sum('delivery_charge');


        /*
        |--------------------------------------------------------------------------
        | Products
        |--------------------------------------------------------------------------
        */

        $totalProducts = Product::count();

        $inactiveProducts = Product::where(
            'status',
            '!=',
            1
        )->count();


        /*
        |--------------------------------------------------------------------------
        | Customers
        |--------------------------------------------------------------------------
        |
        | আপনার users table-এ status = 1 active user হিসেবে ধরা হয়েছে।
        | Customer ID থাকা user-দের customer হিসেবে count করা হয়েছে।
        |
        */

        $totalCustomers = User::whereNotNull(
            'customer_id'
        )->count();

        $todayCustomers = User::whereNotNull(
            'customer_id'
        )
        ->whereDate(
            'created_at',
            $today
        )
        ->count();


        /*
        |--------------------------------------------------------------------------
        | Packages
        |--------------------------------------------------------------------------
        */

        $totalPackages = Package::count();

        $activePackages = Package::where(
            'status',
            1
        )
        ->where(
            'availability',
            1
        )
        ->count();

        $inactivePackages = Package::where(function ($query) {
            $query->where('status', '!=', 1)
                ->orWhere('availability', '!=', 1);
        })->count();


        return view(
            'backend.admin-dashboard.index',
            compact(
                'totalSell',
                'todayPendingAmount',

                'totalOrders',
                'todayOrders',
                'pendingOrders',
                'cancelOrders',

                'totalDeliveryCharge',
                'todayDeliveryCharge',

                'totalProducts',
                'inactiveProducts',

                'totalCustomers',
                'todayCustomers',

                'totalPackages',
                'activePackages',
                'inactivePackages'
            )
        );
    }
    




    public function adminManageProducts(Request $request){
         

        $query = Product::with(['category', 'bazar']);

        // Product Name
        if ($request->filled('name')) {
            $query->where('name', 'like', '%' . $request->name . '%');
        }

        // Category
        if ($request->filled('category')) {
            $query->where('category_id', $request->category);
        }

        // Bazar
        if ($request->filled('bazar')) {
            $query->where('bazar_id', $request->bazar);
        }

        $products = $query->latest()->paginate(10);
        $data['products'] = $products;

       $data['categories'] = Category::orderBy('name')->get();
        $data['bazars'] = Bazar::orderBy('name')->get();

        if ($request->ajax()) {
            return view(
                'backend.admin-dashboard.products.partials.product_table',
                compact('products')
            )->render();
        }


        return view('backend.admin-dashboard.products.manage_products', $data);
    }

    public function adminManageCreateProducts(){
        $data['categories'] = Category::orderBy('id', 'desc')->get();
        $data['riders'] = Rider::orderBy('id', 'desc')->get();
        $data['bazars'] = Bazar::where('status', 'Active')->get();

        return view('backend.admin-dashboard.products.add_products', $data);
    }

    public function ecommerceCreateProducts(){
        $data['categories'] = Category::orderBy('id', 'desc')->get();
        $data['riders'] = Rider::orderBy('id', 'desc')->get();
        $data['bazars'] = Bazar::where('status', 'Active')->get();

        return view('backend.admin-dashboard.products.add_ecom_product', $data);
    }

    public function adminAllOrders(){

        $data['orders'] = [];
 
    $data['deliveryChargeRules'] = DeliveryChargeRule::where('status', true)
        ->orderBy('min_quantity')
        ->get();
 

        return view('backend.admin-dashboard.all_orders', $data);
    }


    public function adminLiveOrders22(Request $request)
    {
        $orders = Order::with(['user', 'rider', 'custom_products', 'items.product'])->latest()->get();

        return response()->json(['orders' => $orders]);
    }
 



public function adminLiveOrders(Request $request)
{
    $orders = Order::with([
        'user',
        'rider',
        'custom_products',
        'items.product'
    ]);

    // Date Filter

if($request->date_filter == 'today'){

    $orders->whereDate('created_at', today());

}
elseif($request->date_filter == 'yesterday'){

    $orders->whereDate('created_at', today()->subDay());

}
elseif(
    $request->date_filter == 'range' &&
    $request->from_date &&
    $request->to_date
){

    $orders->whereBetween('created_at', [
        $request->from_date.' 00:00:00',
        $request->to_date.' 23:59:59'
    ]);

}

if($request->filled('search')){

    $search = $request->search;

    $orders->where(function($q) use($search){

        $q->whereHas('user', function($u) use($search){

           $u->where('name','like',"%{$search}%")->orWhere('phone','like',"%{$search}%");

        })->orWhereHas('rider', function($r) use($search){
            $r->where('name','like',"%{$search}%");
        });

    });

}

// all হলে কোনো date filter হবে না।
 
    // Status

    if($request->filled("status")){

        $orders->where("status",$request->status);

    }

    $orders = $orders->latest()->get();

    return response()->json([
        "orders"=>$orders
    ]);
}



    public function adminRiderList(){

        $data['riders'] = collect([
            (object)[
                'id' => 1,
                'name' => 'মোঃ রহমান',
                'total_delivered' => 120,
                'on_time_delivery' => 110,
                'pending_orders' => 5,
                'cancel_delivery' => 5
            ],
            (object)[
                'id' => 2,
                'name' => 'সেলিম আহমেদ',
                'total_delivered' => 85,
                'on_time_delivery' => 80,
                'pending_orders' => 3,
                'cancel_delivery' => 2
            ],
            (object)[
                'id' => 3,
                'name' => 'জামিল হোসেন',
                'total_delivered' => 150,
                'on_time_delivery' => 140,
                'pending_orders' => 7,
                'cancel_delivery' => 3
            ]
        ]);


 
        return view('backend.admin-dashboard.rider_list', $data);
    }


    public function adminCustomerList(){

        $data['customers'] = [
            (object)[
                'id' => 1,
                'name' => 'Md. Asad',
                'email' => 'asad@mail.com',
                'phone' => '01710000001',
                'total_orders' => 12,
                'pending_orders' => 2,
                'status' => 'active'
            ],
            (object)[
                'id' => 2,
                'name' => 'Rina Akter',
                'email' => 'rina@mail.com',
                'phone' => '01710000002',
                'total_orders' => 8,
                'pending_orders' => 1,
                'status' => 'active'
            ],
            (object)[
                'id' => 3,
                'name' => 'Jamal Hossain',
                'email' => 'jamal@mail.com',
                'phone' => '01710000003',
                'total_orders' => 5,
                'pending_orders' => 0,
                'status' => 'inactive'
            ]
        ];
 
        return view('backend.admin-dashboard.customer_list', $data);
    }


    public function riderProfile(){
        $data['rider'] = (object)[
            'id' => 1,
            'name' => 'Rider Mohsin',
            'email' => 'mohsin@example.com',
            'phone' => '01712345678',
            'avatar' => 'https://via.placeholder.com/100',
            'total_delivered' => 120,
            'on_time_delivery' => 110,
            'on_time_percentage' => 92,
            'pending_orders' => 8,
            'cancel_orders' => 2,
            'total_earnings' => 15000,
            'recent_orders' => [
                (object)[
                    'id' => 12345,
                    'customer_name' => 'Md. Asad',
                    'product_name' => 'Fresh Tomato',
                    'quantity' => 3,
                    'price' => 150,
                    'status' => 'Delivered'
                ],
                (object)[
                    'id' => 12346,
                    'customer_name' => 'Rina Akter',
                    'product_name' => 'Brinjal',
                    'quantity' => 2,
                    'price' => 80,
                    'status' => 'Pending'
                ]
                ],
                
            'created_at' => '2025-10-14 02:41:05',
        ];

 
        return view('backend.rider_profile', $data);
    }


    public function adminStaffList(){
        $data['staffs'] = (object)[
            (object)[
                'id' => 1,
                'name' => 'Md. Asad',
                'email' => 'asad@mail.com',
                'phone' => '01710000001',
                'role' => 'manager',
                'status' => 'active'
            ],
            (object)[
                'id' => 2,
                'name' => 'Rina Akter',
                'email' => 'rina@mail.com',
                'phone' => '01710000002',
                'role' => 'accountant',
                'status' => 'active'
            ],
            (object)[
                'id' => 3,
                'name' => 'Jamal Hossain',
                'email' => 'jamal@mail.com',
                'phone' => '01710000003',
                'role' => 'assistant',
                'status' => 'inactive'
            ]
        ];


 
        return view('backend.admin-dashboard.staff_list', $data);
    }

    public function adminSettings(){
 
        return view('backend.admin-dashboard.admin_settings');
    }



public function printInvoice(Order $order)
{
    $order->load([
        'user',
        'rider',
        'items.product',
        'custom_products',
    ]);

    return view('backend.orders.print', compact('order'));
}


public function bulkPrint(Request $request)
{
    $request->validate([
        'order_ids' => 'required|array|min:1',
        'order_ids.*' => 'integer|exists:orders,id',
    ]);

    $orders = Order::whereIn('id', $request->order_ids)
        ->with([
            'user',
            'rider',
            'items.product',
            'custom_products',
        ])
        ->orderByDesc('id')
        ->get();

    return view('backend.orders.print-bulk', compact('orders'));
}

public function updateCustomPrices(Request $request, Order $order)
{
    $payload = $request->validate([
        'custom_products' => 'required|array|min:1',
        'custom_products.*.id' => 'required|integer',
        'custom_products.*.price' => 'required|numeric|min:0',
    ]);

    DB::beginTransaction();

    try {

        $customProducts = CustomProduct::where('order_id', $order->id)
            ->get()
            ->keyBy('id');

        foreach ($payload['custom_products'] as $item) {

            $custom = $customProducts->get($item['id']);

            if (!$custom) {
                continue;
            }

            $custom->price = $item['price'];
            $custom->save();
        }

        /*
        |--------------------------------------------------------------------------
        | Recalculate Order Total
        |--------------------------------------------------------------------------
        */

        $normalTotal = $order->items()
            ->get()
            ->sum(function ($item) {

                // Rider price থাকলে সেটা ব্যবহার হবে
                $price = (float) ($item->rider_price ?? 0);

                // Rider price না থাকলে normal price
                if ($price <= 0) {
                    $price = (float) ($item->price ?? 0);
                }

                return $price * (float) $item->quantity;
            });


        $customTotal = CustomProduct::where('order_id', $order->id)
            ->get()
            ->sum(function ($item) {

                return (float) $item->price * (float) $item->quantity;
            });


        $grandTotal = $normalTotal + $customTotal;


        $order->total_amount = $grandTotal;
        $order->save();

        DB::commit();


        return response()->json([
            'success' => true,
            'message' => 'Custom product-এর মূল্য সফলভাবে আপডেট হয়েছে।',
            'total_amount' => (float) $grandTotal,
        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([
            'success' => false,
            'message' => 'Server error: ' . $e->getMessage(),
        ], 500);
    }
}

public function setDeliveryCharge(Request $request)
{
    $request->validate([
        'order_id' => 'required|exists:orders,id',
        'delivery_charge' => 'required|numeric|min:0',
    ]);


    $order = Order::findOrFail($request->order_id);


// Custom product price / quantity pending?
$hasPendingCustomPrice = $order->customProducts()
    ->where(function ($query) {

        $query->where(function ($q) {
            $q->where('unit', 'টাকা')
              ->where(function ($q2) {
                  $q2->whereNull('price')
                     ->orWhere('price', '<=', 0);
              });
        })

        ->orWhere(function ($q) {
            $q->where('unit', '!=', 'টাকা')
              ->where(function ($q2) {
                  $q2->whereNull('quantity')
                     ->orWhere('quantity', '<=', 0);
              });
        });

    })
    ->exists();


    if ($hasPendingCustomPrice) {

        return response()->json([
            'success' => false,
            'message' => 'আগে Custom Product-এর Price সেট করুন।'
        ], 422);

    }


    /*
    |--------------------------------------------------------------------------
    | Delivery Charge
    |--------------------------------------------------------------------------
    */

    $deliveryCharge =
        (float) $request->delivery_charge;


    $order->delivery_charge =
        $deliveryCharge;


    /*
    |--------------------------------------------------------------------------
    | Total Amount
    |--------------------------------------------------------------------------
    */

    $productTotal = 0;


    foreach ($order->items as $item) {

        $productTotal +=
            ((float) $item->price *
             (float) $item->quantity);

    }


    $customTotal = 0;


    foreach ($order->customProducts as $item) {

        $customTotal +=
            ((float) $item->price *
             (float) $item->quantity);

    }


    $order->total_amount =
        $productTotal +
        $customTotal +
        $deliveryCharge;


    $order->save();


    return response()->json([

        'success' => true,

        'delivery_charge' =>
            $order->delivery_charge,

        'total_amount' =>
            $order->total_amount,

    ]);
}



}
